#!/bin/bash
thisdir=$(dirname "$0")
cd $thisdir
./qmfm2.py
